package ro.usv.rf;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class MainClass {
    public static final String PATH = "D:\\Facultate\\Facultate Calculatoare anul IV\\RF\\Laborator\\Laborator_02\\src\\";

    public static void main(String[] args) {
        double[][] matrice = FileUtils.readLearningSetFromFile(PATH + "in.txt");

        int rows = matrice.length;
        int columns = matrice[0].length;

        System.out.println(rows + ", " + columns);

        //calculate average for each feature
        for (int j = 0; j < columns; j++) {
            Double[] column = new Double[rows];
            for (int i = 0; i < rows; i++) {
                column[i] = matrice[i][j];
            }

            System.out.println("Column = " + Arrays.toString(column));

            double featureAverage = StatisticsUtils.getAverage(column);
            System.out.println("Feature average is : " + featureAverage);
        }

        //get weights from matrix - only after you add the new line !!!
        // since the last column represent the weights, the number of features is now learningSet[0].length - 1
        columns = matrice[0].length - 1;

        Double[] weights = new Double[rows];
        for (int i = 0; i < rows; i++) {
            // weights are always located on the last  column
            int weightColumn = matrice[i].length - 1;
            weights[i] = matrice[i][weightColumn];
        }

        // calculate Feature Weighted Average and feature dispersion
        List<Double[]> featureList = new ArrayList<>();
        double[] weightedAverages = new double[columns];
        double[] dispersions = new double[columns];
        double[] averageSquareDeviations = new double[columns];

        for (int i = 0; i < columns; i++) {
            Double[] column = new Double[rows];
            for (int j = 0; j < rows; j++) {
                column[j] = matrice[j][i];
            }
            featureList.add(column);
            System.out.println("\nColumn " + i);

            weightedAverages[i] = StatisticsUtils.getWeightedAverage(column, weights);
            System.out.println("Feature weighted average is : " + weightedAverages[i]);

            dispersions[i] = StatisticsUtils.getFeatureDispersion(column, weightedAverages[i]);
            System.out.println("Feature dispersion is : " + dispersions[i]);

            averageSquareDeviations[i] = StatisticsUtils.getAverageSquareDeviation(dispersions[i]);
            System.out.println("Average square deviations is : " + averageSquareDeviations[i]);
        }

        //we select a feature and an element to calculate frequency of occurence

        int row = 2;
        int column = 0;
        Map<Double, Integer> counterMap = StatisticsUtils.getCounterMap(featureList.get(column));
        double frequencyOfOccurence = StatisticsUtils.getFrequencyOfOccurence(counterMap, matrice[row][column]);
        System.out.println("\nFrequency of occurence for element [" + row + "," + column + "] = " +
                matrice[row][column] + " is : " + frequencyOfOccurence);

        //we select two features to calculate covariance and corelation
        int feature1Index = 0;
        int feature2Index = 1;

        double covariance = StatisticsUtils.getCovariance(featureList.get(feature1Index), featureList.get(feature2Index),
                weightedAverages[feature1Index], weightedAverages[1]);
        System.out.println("\nCovariance is : " + covariance);

        double corelation = StatisticsUtils.getCorrelationCoefficient(covariance, dispersions[feature1Index], dispersions[feature2Index]);
        System.out.println("\nCorelation is : " + corelation);


        FileUtils.writeLearningSetToFile(PATH + "scaledSet.csv", StatisticsUtils.autoscaleLearningSet(matrice, weightedAverages));
    }


}