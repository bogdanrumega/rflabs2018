package ro.usv.rf;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class StatisticsUtils {
    private static Double calculateSum1(double value, int count) {
        return count * value;
    }

    protected static Map<Double, Integer> getCounterMap(Double column[]) {
        Map<Double, Integer> counterMap = new HashMap<>();
        int length = column.length;

        for (int j = 0; j < length; j++) {
            if (counterMap.containsKey(column[j])) {
                int count = counterMap.get(column[j]);
                counterMap.put(column[j], ++count);
            } else {
                counterMap.put(column[j], 1);
            }
        }
        return counterMap;
    }

    protected static double getAverage(Double[] column) {
        Map<Double, Integer> counterMap = getCounterMap(column);
        double average = 0.0;

        double sum1 = 0.0;
        double sum2 = 0.0;

        sum1 = counterMap.keySet()
                .stream()
                .mapToDouble(x -> calculateSum1(x, counterMap.get(x)))
                .sum();

        sum2 = counterMap.values()
                .stream()
                .mapToInt(x -> x)
                .sum();

        average = sum1 / sum2;

        System.out.println("The feature average is: " + average);

        return average;
    }

    protected static double getWeightedAverage(Double[] column, Double[] weights) {
        double weightedAverage = 0.0;
        double colAvg = 0.0;

        int len = column.length;
        for (int i = 0; i < len; i++) {
            colAvg += column[i] * weights[i];
        }

        double weightSum = Arrays.stream(weights)
                .mapToDouble(x -> x)
                .sum();

        weightedAverage = colAvg / weightSum;

        return weightedAverage;
    }

    protected static double getFrequencyOfOccurence(Map<Double, Integer> counterMap, double featureElement) {
        double frequencyOfOccurence = 0.0;

        int count = counterMap.get(featureElement);
        int length = counterMap.size();

        frequencyOfOccurence = (double) count / (double) length;

        return frequencyOfOccurence;
    }

    protected static double getFeatureDispersion(Double[] column, double weightedAverage) {
        double dispersion = 0.0;

        double n = column.length;
        double sum = Arrays.stream(column)
                .mapToDouble(x -> (x - weightedAverage) * (x - weightedAverage))
                .sum();

        dispersion = sum * (1.0 / (n - 1));

        return dispersion;
    }

    protected static double getCovariance(Double[] feature1, Double[] feature2,
                                          double weightedAverage1, double weightedAverage2) {
        double covariance = 0.0;
        double sum = 0.0;

        int n = feature1.length;

        for (int i = 0; i < n; i++) {
            sum += (feature1[i] - weightedAverage1) * (feature2[i] - weightedAverage2);
        }

        covariance = sum * (1.0 / (n - 1));

        return covariance;
    }

    protected static double getCorrelationCoefficient(double covariance, double feature1Dispersion,
                                                      double feature2Dispersion) {
        double correlationCoefficient = covariance / Math.sqrt(feature1Dispersion * feature2Dispersion);

        return correlationCoefficient;
    }

    protected static double getAverageSquareDeviation(double dispersion) {
        double averageSquareDeviation = 0.0;

        averageSquareDeviation = Math.sqrt(dispersion);

        return averageSquareDeviation;
    }

    protected static double getFeatureSum(Double[] column, double weightedAverage) {
        double dispersion = 0.0;

        double n = column.length;
        double sum = Arrays.stream(column)
                .mapToDouble(x -> (x - weightedAverage) * (x - weightedAverage))
                .sum();

        return sum;
    }

    protected static double[][] autoscaleLearningSet(double[][] learningSet, double[] weightedAverages) {
        int rows = learningSet.length;
        int columns = learningSet[0].length;

        double[][] autoscaledLearningSet = new double[rows][];
        for (int i = 0; i < rows; i++) {
            autoscaledLearningSet[i] = new double[columns-1];
        }

        for (int j = 0; j < columns-1; j++) {
            Double[] column = new Double[rows];
            for (int i = 0; i < rows; i++) {
                column[i] = learningSet[i][j];
            }

            for (int i = 0; i < rows; i++) {
                double val = (learningSet[i][j] - weightedAverages[j]) / getFeatureSum(column, weightedAverages[j]);
                autoscaledLearningSet[i][j] = val;
            }
        }

        return autoscaledLearningSet;
    }
}