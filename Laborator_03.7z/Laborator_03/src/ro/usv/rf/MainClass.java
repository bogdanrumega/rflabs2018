package ro.usv.rf;

public class MainClass {
    private static final String PATH = "D:\\Facultate\\Facultate Calculatoare anul IV\\RF\\Laborator\\Laborator_03\\src\\";

    public static void main(String[] args) {
        double[][] learningSet = null;
        try {
            learningSet = FileUtils.readLearningSetFromFile(PATH + "in.txt");
            int numberOfPatterns = learningSet.length;
            int numberOfFeatures = learningSet[0].length;
            System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
        } catch (USVInputFileCustomException e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Finished learning set operations\n");
        }

        int rows = learningSet.length;
        int cols = learningSet[0].length;

        /* b) Euclidian distance */
        for (int i = 1; i < rows; i++) {
            System.out.println("Euclidian distance pattern 0 -> pattern " + i + " = " + DistanceUtils.distEuclidian(0, i, learningSet));
        }
        System.out.println();

        /* c) Mahalanobis distance */
        for (int i = 1; i < rows; i++) {
            System.out.println("Mahalanobis distance pattern 0 -> pattern " + i + " = " + DistanceUtils.distMahalanobis(0, i, learningSet));
        }
        System.out.println();

        /* d) Cebisev distance */
        for (int i = 1; i < rows; i++) {
            System.out.println("Cebisev distance pattern 0 -> pattern " + i + " = " + DistanceUtils.distCebisev(0, i, learningSet));
        }
        System.out.println();

        /* e) City Block distance */
        for (int i = 1; i < rows; i++) {
            System.out.println("City Block distance pattern 0 -> pattern " + i + " = " + DistanceUtils.distCityBlock(0, i, learningSet));
        }
    }
}