package ro.usv.rf;

public class DistanceUtils {
    public static double distEuclidian(int col1, int col2, double[][] learningSet) {
        double x1 = learningSet[col1][0];
        double y1 = learningSet[col1][1];
        double x2 = learningSet[col2][0];
        double y2 = learningSet[col2][1];

        return Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
    }

    public static double distMahalanobis(int col1, int col2, double[][] learningSet) {
        int n = learningSet.length; // rows
        int p = learningSet[0].length; // columns
        double sum = 0.0;

        for (int i = 0; i < p; i++) {
            double xj = learningSet[col1][i];
            double yj = learningSet[col2][i];

            double dif = xj - yj;

            sum += Math.pow(dif, n);

        }

        return Math.pow(sum, (1.0 / n));
    }

    public static double distCebisev(int col1, int col2, double[][] learningSet) {
        int p = learningSet[0].length; // columns
        double max = 0.0;

        for (int i = 0; i < p; i++) {
            double xj = learningSet[col1][i];
            double yj = learningSet[col2][i];

            double modulo = Math.abs(xj - yj);

            if (modulo > max) max = modulo;
        }

        return max;
    }

    public static double distCityBlock(int col1, int col2, double[][] learningSet) {
        int p = learningSet[0].length; // columns
        double sum = 0.0;

        for (int i = 0; i < p; i++) {
            double xj = learningSet[col1][i];
            double yj = learningSet[col2][i];

            sum += Math.abs(xj - yj);

        }

        return sum;

    }
}