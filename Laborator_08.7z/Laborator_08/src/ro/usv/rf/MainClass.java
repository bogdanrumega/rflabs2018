package ro.usv.rf;

public class MainClass {
    public static void main(String[] args) {
        final String PATH = "D:\\Facultate\\Facultate Calculatoare anul IV\\RF\\Laborator\\Laborator_08\\";

        int[][] learningSet = null;
        try {
            learningSet = FileUtils.readLearningSetFromFile(PATH + "in.txt");
            int numberOfPatterns = learningSet.length;
            int numberOfFeatures = learningSet[0].length;
            System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
        } catch (USVInputFileCustomException e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Finished learning set operations\n");
        }

        int[] clase = dynamicKernels(learningSet, 2);

        int k = 0;
        for (int c : clase) {
            System.out.println("Clasa pt " + k + " = " + c);
            k++;
        }
    }

    /**
     * dynamicKernels - metoda K generalizata
     *
     * @param x - setul de date
     * @param M - nr de nuclee
     */
    public static int[] dynamicKernels(int[][] x, int M) {
        int n = x.length;
        int p = x[0].length;

        int[][] c = new int[M][p];
        int[] iclass = new int[n];

        boolean done;

        for (int i = 0; i < M; i++) {
            c[i] = x[i];
        }

        do {
            double dmin;
            double dik;

            done = true;

            double[][] g = new double[M][p];
            int[] miu = new int[M];
            int kmin = 0;

            for (int i = 0; i < n; i++) {
                dmin = Double.MAX_VALUE;

                for (int k = 0; k < M; k++) {
                    dik = calculateDistance(x[i], c[k]);
                    if (dik < dmin) {
                        dmin = dik;
                        kmin = k;
                    }
                }
                miu[kmin] += 1;

                for (int j = 0; j < p; j++) {
                    g[kmin][j] += x[i][j];
                }

                if (iclass[i] != kmin) {
                    iclass[i] = kmin;
                    done = false;
                }
            }

            if (!done) {
                for (int k = 0; k < M; k++) {
                    for (int j = 0; j < p; j++) {
                        g[k][j] /= (double) miu[k];
                    }
                }
            }
        } while (!done);

        return iclass;
    }

    public static double calculateDistance(int[] x, int[] k) {
        double dist = 0.0;

        int n = x.length;

        for (int i = 0; i < n; i++) {
            dist += (x[i] - k[i]) * (x[i] - k[i]);
        }

        return Math.sqrt(dist);
    }
}