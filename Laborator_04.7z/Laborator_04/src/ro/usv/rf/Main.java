package ro.usv.rf;

import java.util.Arrays;

public class Main {
    private static final String PATH = "D:\\Facultate\\Facultate Calculatoare anul IV\\RF\\Laborator\\Laborator_04\\";

    public static double distEuclidian(int x, int y, double[][] learningSet) {
        int cols = learningSet[0].length - 1;
        double sum = 0.0;
        double dif;

        for (int i = 0; i < cols; i++) {
            dif = learningSet[x][i] - learningSet[y][i];
            sum += dif * dif;
        }

        return Math.sqrt(sum);
    }

    public static double patternClass(int p, double[][] matrix, double[][] learningSet) {
        int col = 0;

        int cols = matrix[0].length;
        double min = Double.MAX_VALUE;

        for (int j = 0; j < cols; j++) {
            if (j != p) {
                if (matrix[p][j] < min) {
                    min = matrix[p][j];
                    col = j;
                }
            }
        }

        return learningSet[col][cols - 1];
    }

    public static void main(String[] args) {
        double[][] learningSet = null;
        try {
            learningSet = FileUtils.readLearningSetFromFile(PATH + "in2.txt");
            int numberOfPatterns = learningSet.length;
            int numberOfFeatures = learningSet[0].length;
            System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
        } catch (USVInputFileCustomException e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Finished learning set operations\n");
        }

        int rows = learningSet.length; // 'line' sau 'pattern'
        int cols = learningSet[0].length; // feature

        double[][] matrix = new double[rows][rows];

        for (int i = 0; i < rows; i++) {
            for (int j = i + 1; j < rows; j++) {
                matrix[i][j] = distEuclidian(i, j, learningSet);
                matrix[j][i] = matrix[i][j];
            }
        }

        for (int i = 0; i < rows; i++) {
            System.out.println(Arrays.toString(matrix[i]));
        }

        System.out.println("Clasa = " + patternClass(4, matrix, learningSet));
    }
}