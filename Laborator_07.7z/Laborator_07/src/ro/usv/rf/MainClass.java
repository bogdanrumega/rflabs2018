package ro.usv.rf;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

public class MainClass {
    public static void main(String[] args) {
        final String PATH = "D:\\Facultate\\Facultate Calculatoare anul IV\\RF\\Laborator\\Laborator_07\\src\\";

        int[][] learningSet = null;
        int[][] patternSet = null;
        try {
            learningSet = FileUtils.readLearningSetFromFile(PATH + "in.txt");
            patternSet = FileUtils.readLearningSetFromFile(PATH + "patterns.txt");
            int numberOfPatterns = learningSet.length;
            int numberOfFeatures = learningSet[0].length;
            System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
        } catch (USVInputFileCustomException e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Finished learning set operations");
        }

        ArrayList<Integer> classes = getDistinctClasses(learningSet);
        int c = classes.size();
        int n = c + 1;
        double[][] matrix = new double[c][n];

        System.out.println("Found " + c + " distinct classes: " + Arrays.toString(classes.toArray()));

        int k = 0;
        for (int fc : classes) {
            int[][] classSet = getClassFeatures(learningSet, fc);
            double w[] = getClassW(classSet, fc);

            matrix[k] = w;
            k++;
        }

        System.out.println();

        for (int i = 0; i < patternSet.length; i++) {
            int cl = getPsi(matrix, patternSet[i], classes);
            System.out.println("Class for set " + Arrays.toString(patternSet[i]) + " is " + cl);
        }
    }

    public static ArrayList<Integer> getDistinctClasses(int[][] learningSet) {
        ArrayList<Integer> classes = new ArrayList<>();

        int patterns = learningSet.length;
        int features = learningSet[0].length;
        int c;

        for (int i = 0; i < patterns; i++) {
            c = learningSet[i][features - 1];
            if (!classes.contains(c)) classes.add(c);
        }

        return classes;
    }

    public static int[][] getClassFeatures(int[][] learningSet, int cl) {
        int patterns = learningSet.length;
        int features = learningSet[0].length;
        int c;
        int n = 0;

        for (int i = 0; i < patterns; i++) {
            c = learningSet[i][features - 1];
            if (c == cl) n++;
        }

        int k = 0;
        int[][] classes = new int[n][features];

        for (int i = 0; i < patterns; i++) {
            c = learningSet[i][features - 1];
            if (c == cl) {
                for (int j = 0; j < features; j++) {
                    classes[k][j] = learningSet[i][j];
                }
                k++;
            }
        }

        return classes;
    }

    public static double[] getClassW(int[][] classFeatures, int c) {
        int patterns = classFeatures.length;
        int features = classFeatures[0].length;

        int n = features - 1 + 1;
        double[] w = new double[n];

        double square = 0;

        for (int j = 0; j < features - 1; j++) {
            double med = 0.0;
            for (int i = 0; i < patterns; i++) {
                med += classFeatures[i][j];
            }
            w[j] = med / patterns;

            square += w[j] * w[j];
        }

        w[n - 1] = square * (-0.5);

        System.out.println("Class: " + c + " : " + Arrays.toString(w));

        return w;
    }

    public static int getPsi(double[][] w, int[] set, ArrayList<Integer> classes) {
        int psis = w.length;
        int feat = w[0].length;

        double[] psi = new double[psis];

        for (int i = 0; i < psis; i++) {
            double p = 0.0;
            for (int j = 0; j < feat - 1; j++) {
                p += w[i][j] * set[j];
            }
            psi[i] = p + w[i][feat-1];
        }

        System.out.println(Arrays.toString(psi));

        return 0;
    }
}